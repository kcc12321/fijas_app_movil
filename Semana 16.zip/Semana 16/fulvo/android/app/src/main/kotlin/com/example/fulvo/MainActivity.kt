package com.example.fulvo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
