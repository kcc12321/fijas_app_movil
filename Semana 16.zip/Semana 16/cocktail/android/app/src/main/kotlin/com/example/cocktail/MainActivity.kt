package com.example.cocktail

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
