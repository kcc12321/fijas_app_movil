package com.example.app_mycinees2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
